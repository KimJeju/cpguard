package com.example.excample_state

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
